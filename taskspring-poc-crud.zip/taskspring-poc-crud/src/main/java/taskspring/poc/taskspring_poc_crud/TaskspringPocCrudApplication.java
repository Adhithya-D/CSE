package taskspring.poc.taskspring_poc_crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskspringPocCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskspringPocCrudApplication.class, args);
	}

}
